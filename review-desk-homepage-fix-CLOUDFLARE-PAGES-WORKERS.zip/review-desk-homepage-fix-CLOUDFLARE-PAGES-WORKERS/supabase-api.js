(() => {
  const STORAGE_KEY='reviewdesk_auth_session';
  let session=loadSession();
  let accessToken=session?.access_token||'';

  function loadSession(){
    try{
      const raw=localStorage.getItem(STORAGE_KEY);
      return raw?JSON.parse(raw):null;
    }catch{return null}
  }
  function saveSession(d){
    session=d||null;
    accessToken=d?.access_token||'';
    try{
      if(d) localStorage.setItem(STORAGE_KEY,JSON.stringify(d));
      else localStorage.removeItem(STORAGE_KEY);
    }catch{}
  }
  function config(){
    const c=window.REVIEW_CONFIG||{};
    const url=String(c.url||'').trim().replace(/\/$/,'');
    const key=String(c.key||'').trim();
    if(!/^https:\/\/[a-z0-9-]+\.supabase\.co$/.test(url))throw new Error('Add your Supabase project URL and publishable key in config.js.');
    let allowed=key.startsWith('sb_publishable_');
    if(!allowed&&key.split('.').length===3){try{const s=key.split('.')[1].replace(/-/g,'+').replace(/_/g,'/');allowed=JSON.parse(atob(s)).role==='anon'}catch{}}
    if(!allowed)throw new Error('Use a publishable key or legacy anon key, never a secret/service_role key.');
    return {url,key};
  }
  async function rawRequest(path,body={},authenticated=false,tokenOverride=''){
    const c=config(),headers={apikey:c.key,'Content-Type':'application/json'};
    if(c.key.startsWith('eyJ'))headers.Authorization='Bearer '+c.key;
    const token=tokenOverride||accessToken;
    if(authenticated){if(!token)throw new Error('Please sign in.');headers.Authorization='Bearer '+token}
    const r=await fetch(c.url+path,{method:'POST',headers,body:JSON.stringify(body),cache:'no-store'});
    let d;try{d=await r.json()}catch{d={}}
    if(!r.ok){
      const error=new Error(d.message||d.msg||d.error_description||d.error||'Supabase request failed. Check setup-multibusiness.sql and project settings.');
      error.status=r.status;
      throw error;
    }
    return d;
  }
  async function refresh(){
    const refreshToken=session?.refresh_token;
    if(!refreshToken)return false;
    try{
      const d=await rawRequest('/auth/v1/token?grant_type=refresh_token',{refresh_token:refreshToken},false);
      saveSession(d);
      return true;
    }catch{return false}
  }
  async function request(path,body={},authenticated=false){
    try{
      return await rawRequest(path,body,authenticated);
    }catch(e){
      if(authenticated&&e.status===401&&await refresh()) return rawRequest(path,body,true);
      if(authenticated&&e.status===401) saveSession(null);
      throw e;
    }
  }

  async function tableInsert(table, rows){
    const c=config();
    if(!accessToken) throw new Error('Please sign in.');
    const r=await fetch(c.url+'/rest/v1/'+table,{
      method:'POST',
      headers:{
        apikey:c.key,
        Authorization:'Bearer '+accessToken,
        'Content-Type':'application/json',
        Prefer:'return=minimal'
      },
      body:JSON.stringify(rows),
      cache:'no-store'
    });
    let d;try{d=await r.json()}catch{d=null}
    if(!r.ok){
      const msg=d?.message||d?.details||d?.hint||d?.error||'Could not save the business profile.';
      const error=new Error(msg);error.status=r.status;throw error;
    }
    return d;
  }

  window.ReviewDB={
    config,
    rpc:(name,args={},admin=false)=>request('/rest/v1/rpc/'+name,args,admin),
    tableInsert,
    async login(email,password){const d=await rawRequest('/auth/v1/token?grant_type=password',{email,password});saveSession(d);return d},
    async signup(email,password){const d=await rawRequest('/auth/v1/signup',{email,password});if(d.access_token)saveSession(d);return d},
    async logout(){try{if(accessToken)await rawRequest('/auth/v1/logout',{},true)}catch{}finally{saveSession(null)}},
    reset(){saveSession(null)},
    hasSession(){return !!accessToken},
    session(){return session}
  };
})();
