const $=id=>document.getElementById(id);
let current=null,busy=false,timer,redirectURL='',copyRetry=null,slug='',business=null;
const pathSlug=()=>{
  // The site homepage must never be treated as a business slug. This also
  // supports opening index.html directly and hosting under a project folder.
  const path=decodeURIComponent(location.pathname||'/');
  const parts=path.split('/').filter(Boolean);
  if(!parts.length || /(^|\/)index\.html?$/i.test(path)) return '';
  if(parts.length===1 && /^(index|reviewapp)$/i.test(parts[0])) return '';
  return parts[0]||'';
};
const normalizeSlug=value=>String(value||'').trim().toLowerCase().replace(/^\/+|\/+$/g,'').split('/')[0];
function status(text=''){$('status').textContent=text;}
function fitReview(){}
function controls(){
  $('next').disabled=busy;
  $('use').disabled=busy||(!current&&!redirectURL);
  $('review').disabled=busy||!current;
}
function clear(){clearTimeout(timer);current=null;$('review').value='';$('review').hidden=false;controls();}
function expire(){clear();status('Review expired. Tap Next review.');}
function arm(){clearTimeout(timer);if(current?.expires)timer=setTimeout(expire,Math.max(0,current.expires-Date.now()-1000));}
async function copy(text){try{await navigator.clipboard.writeText(text);return true}catch{const area=document.createElement('textarea');area.value=text;area.className='clipboard-helper';area.setAttribute('aria-hidden','true');document.body.append(area);area.select();try{return document.execCommand('copy')}catch{return false}finally{area.remove()}}}
async function next(){
  if(busy||!slug)return;busy=true;const previous=current?.lease||null;redirectURL='';copyRetry=null;clear();status('Loading…');
  try{const d=await ReviewDB.rpc('rd_mb_claim',{p_slug:slug,p_previous:previous});
    business=d.business||business; $('businessName').textContent=business?.name||'Review';
    if(d.review){current=d.review;$('review').value=d.review.text;arm();status('');}
    else status('No unused review drafts are available right now. You can still write your own review and continue to Google.');
  }catch(e){status(e.message||'Unable to load this review page.')}finally{busy=false;controls();}
}
$('next').onclick=next;
$('use').onclick=async()=>{
  if(busy)return;
  if(redirectURL){busy=true;controls();try{if(copyRetry&&!await copy(copyRetry)){status('Copy blocked. Allow clipboard access and tap again.');return}window.location.assign(redirectURL)}finally{busy=false;controls()}return}
  if(!current){window.open(business?.url||'#','_blank','noopener');return;}
  const text=$('review').value.trim(),lease=current.lease;if(!text){status('Enter your review first.');return}
  busy=true;clear();status('Preparing Google review…');
  try{const d=await ReviewDB.rpc('rd_mb_use',{p_slug:slug,p_token:lease});redirectURL=d.url;copyRetry=text;if(await copy(text)){copyRetry=null;status('Copied. Opening Google…');window.location.assign(d.url)}else status('Copy blocked. Allow clipboard access, then tap Copy & Continue again.')}catch(e){status(e.message+' Please tap Next review.')}finally{busy=false;controls();}
};
setInterval(async()=>{if(!current||busy||document.hidden)return;const lease=current.lease;try{const d=await ReviewDB.rpc('rd_mb_renew',{p_slug:slug,p_token:lease});if(current?.lease===lease){current.expires=d.expires;arm()}}catch{if(current?.lease===lease)expire()}},30000);
document.addEventListener('visibilitychange',async()=>{if(document.hidden){$('review').hidden=true;return}$('review').hidden=false;const lease=current?.lease;if(!lease)return;try{const d=await ReviewDB.rpc('rd_mb_renew',{p_slug:slug,p_token:lease});if(current?.lease===lease){current.expires=d.expires;arm()}}catch{if(current?.lease===lease)expire()}});
function show(mode){$('landing').hidden=mode!=='landing';$('reviewApp').hidden=mode!=='review';$('notFound').hidden=mode!=='notFound';}
const lookupForm=$('lookupForm');if(lookupForm)lookupForm.onsubmit=e=>{e.preventDefault();const value=$('slugLookup').value.trim().toLowerCase().replace(/\s+/g,'-');if(value)location.assign('/'+encodeURIComponent(value))};
(async()=>{
  try{ReviewDB.config();}catch(e){$('notFoundText').textContent=e.message;show('notFound');return}
  slug=normalizeSlug(pathSlug());
  if(!slug){show('landing');return}
  try{const d=await ReviewDB.rpc('rd_mb_public_business',{p_slug:slug});if(!d){$('notFoundText').textContent=`No business is registered at /${slug}.`;show('notFound');return}business=d;document.title=d.name+' — Reviews';$('businessName').textContent=d.name;$('businessHint').textContent='Use the suggested review below, edit it to match your real experience, then continue to Google.';show('review');await next()}catch(e){$('notFoundText').textContent=e.message||'This review page is unavailable.';show('notFound')}})();
