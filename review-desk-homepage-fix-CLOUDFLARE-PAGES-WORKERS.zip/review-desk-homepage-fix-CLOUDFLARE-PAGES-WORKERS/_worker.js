/**
 * Review Desk - Cloudflare Workers Static Assets entrypoint.
 *
 * Cloudflare's Worker runtime does not use Netlify's netlify.toml redirects.
 * This worker provides the same SPA fallback so direct business URLs such as
 * /himywork5 work on workers.dev and on a custom domain.
 */
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = decodeURIComponent(url.pathname || '/');

    // Never rewrite real asset/file requests.
    const hasFileExtension = /\.[a-z0-9]{1,12}$/i.test(path);

    // Admin has a real HTML entrypoint, but /admin is the public URL.
    if (path === '/admin' || path === '/admin/') {
      const adminUrl = new URL(request.url);
      adminUrl.pathname = '/admin.html';
      return env.ASSETS.fetch(new Request(adminUrl, request));
    }

    // Root and real files should be served normally.
    if (path === '/' || hasFileExtension) {
      return env.ASSETS.fetch(request);
    }

    // Every extensionless path is a business slug. Serve index.html and let
    // app.js read location.pathname and load the matching business from Supabase.
    const indexUrl = new URL(request.url);
    indexUrl.pathname = '/index.html';
    return env.ASSETS.fetch(new Request(indexUrl, request));
  }
};
