-- MULTI-BUSINESS REVIEW PLATFORM SETUP
-- Run this file in Supabase SQL Editor.
-- It uses rd_mb_* names so it does not touch the old single-business rd_* tables.

begin;

create extension if not exists pgcrypto;

create table if not exists public.rd_mb_businesses (
  id uuid primary key default gen_random_uuid(),
  owner_user_id uuid not null unique references auth.users(id) on delete cascade,
  name text not null,
  slug text not null unique,
  google_review_url text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists public.rd_mb_admins (
  business_id uuid not null references public.rd_mb_businesses(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (business_id, user_id),
  unique (user_id)
);

create table if not exists public.rd_mb_reviews (
  id bigint generated always as identity primary key,
  business_id uuid not null references public.rd_mb_businesses(id) on delete cascade,
  body text not null,
  fingerprint text not null,
  used_at timestamptz,
  lease_hash text unique,
  expires_at timestamptz,
  created_at timestamptz not null default now(),
  unique (business_id, fingerprint)
);

create index if not exists rd_mb_reviews_available_idx
on public.rd_mb_reviews (business_id, expires_at, id)
where used_at is null;

create index if not exists rd_mb_reviews_business_idx
on public.rd_mb_reviews (business_id, id desc);

alter table public.rd_mb_businesses enable row level security;
alter table public.rd_mb_admins enable row level security;
alter table public.rd_mb_reviews enable row level security;

revoke all on public.rd_mb_businesses, public.rd_mb_admins, public.rd_mb_reviews from public, anon, authenticated;
revoke all on sequence public.rd_mb_reviews_id_seq from public, anon, authenticated;

create or replace function public.rd_mb_hash(p_value text) returns text
language sql immutable set search_path='' as $$
  select pg_catalog.encode(pg_catalog.sha256(pg_catalog.convert_to(p_value,'UTF8')),'hex');
$$;

create or replace function public.rd_mb_normalize_slug(p_value text) returns text
language sql immutable set search_path='' as $$
  select regexp_replace(lower(btrim(coalesce(p_value,''))), '[^a-z0-9]+', '-', 'g');
$$;

create or replace function public.rd_mb_assert_auth() returns void
language plpgsql security definer set search_path='' as $$
begin
  if auth.uid() is null then
    raise exception 'Please sign in.' using errcode='42501';
  end if;
end;
$$;

create or replace function public.rd_mb_business_for_user() returns uuid
language sql stable security definer set search_path='' as $$
  select business_id from public.rd_mb_admins where user_id = auth.uid() limit 1;
$$;

create or replace function public.rd_mb_assert_admin() returns uuid
language plpgsql security definer set search_path='' as $$
declare bid uuid;
begin
  perform public.rd_mb_assert_auth();
  select business_id into bid from public.rd_mb_admins where user_id = auth.uid() limit 1;
  if bid is null then
    raise exception 'Business setup is incomplete. Create your business profile first.' using errcode='42501';
  end if;
  return bid;
end;
$$;

create or replace function public.rd_mb_validate_google_url(p_url text) returns boolean
language sql immutable set search_path='' as $$
  select coalesce(p_url,'') ~ '^https://(g[.]page|maps[.]app[.]goo[.]gl|goo[.]gl|([a-zA-Z0-9-]+[.])*google[.]com)(/[^[:space:]]*)?$';
$$;

drop function if exists public.rd_mb_register_business(text,text);
drop function if exists public.rd_mb_register_business(text,text,text);

create or replace function public.rd_mb_register_business(p_name text, p_slug text, p_url text) returns jsonb
language plpgsql security definer set search_path='' as $$
declare bid uuid; clean_slug text; clean_name text; clean_url text;
begin
  perform public.rd_mb_assert_auth();

  if exists(select 1 from public.rd_mb_admins where user_id = auth.uid()) then
    select business_id into bid from public.rd_mb_admins where user_id = auth.uid();
    return public.rd_mb_my_business();
  end if;

  clean_name := btrim(coalesce(p_name,''));
  clean_slug := public.rd_mb_normalize_slug(p_slug);
  clean_url := btrim(coalesce(p_url,''));

  if length(clean_name) < 2 or length(clean_name) > 100 then
    raise exception 'Business name must be 2–100 characters.';
  end if;
  if length(clean_slug) < 3 or length(clean_slug) > 60 or clean_slug !~ '^[a-z0-9]+(?:-[a-z0-9]+)*$' then
    raise exception 'Business URL must contain 3–60 lowercase letters, numbers, and hyphens.';
  end if;
  if clean_slug in ('admin','api','login','signup','dashboard','review','reviews','index','favicon','robots','sitemap') then
    raise exception 'That business URL is reserved. Choose another one.';
  end if;
  if clean_url <> '' and not public.rd_mb_validate_google_url(clean_url) then
    raise exception 'Enter a valid HTTPS Google review link.';
  end if;
  if exists(select 1 from public.rd_mb_businesses where slug = clean_slug) then
    raise exception 'That business URL is already taken. Choose another one.' using errcode='23505';
  end if;

  insert into public.rd_mb_businesses(owner_user_id, name, slug, google_review_url)
  values(auth.uid(), clean_name, clean_slug, clean_url)
  returning id into bid;

  insert into public.rd_mb_admins(business_id, user_id)
  values(bid, auth.uid())
  on conflict (user_id) do nothing;

  return jsonb_build_object(
    'business', jsonb_build_object(
      'id', bid,
      'name', clean_name,
      'slug', clean_slug,
      'url', clean_url
    )
  );
end;
$$;

create or replace function public.rd_mb_my_business() returns jsonb
language plpgsql security definer set search_path='' as $$
declare bid uuid; b public.rd_mb_businesses%rowtype; stats jsonb;
begin
  perform public.rd_mb_assert_auth();
  select business_id into bid from public.rd_mb_admins where user_id = auth.uid() limit 1;
  if bid is null then
    return jsonb_build_object('business', null);
  end if;
  select * into b from public.rd_mb_businesses where id=bid;
  select jsonb_build_object(
    'total', count(*),
    'used', count(*) filter(where used_at is not null),
    'reserved', count(*) filter(where used_at is null and expires_at > clock_timestamp()),
    'available', count(*) filter(where used_at is null and (expires_at is null or expires_at <= clock_timestamp()))
  ) into stats from public.rd_mb_reviews where business_id=bid;
  return jsonb_build_object(
    'business', jsonb_build_object('id',b.id,'name',b.name,'slug',b.slug,'url',b.google_review_url),
    'stats',stats
  );
end;
$$;

create or replace function public.rd_mb_admin_settings(p_name text, p_url text) returns jsonb
language plpgsql security definer set search_path='' as $$
declare bid uuid; clean_name text; clean_url text;
begin
  bid := public.rd_mb_assert_admin();
  clean_name := btrim(coalesce(p_name,''));
  clean_url := btrim(coalesce(p_url,''));
  if length(clean_name) < 2 or length(clean_name) > 100 then
    raise exception 'Business name must be 2–100 characters.';
  end if;
  if clean_url <> '' and not public.rd_mb_validate_google_url(clean_url) then
    raise exception 'Enter a valid HTTPS Google review link.';
  end if;
  update public.rd_mb_businesses set name=clean_name, google_review_url=clean_url where id=bid;
  return public.rd_mb_my_business();
end;
$$;

create or replace function public.rd_mb_import_reviews(p_reviews text[]) returns jsonb
language plpgsql security definer set search_path='' as $$
declare bid uuid; item text; inserted integer:=0; changed integer; normalized text;
begin
  bid := public.rd_mb_assert_admin();
  if p_reviews is null or cardinality(p_reviews)<1 or cardinality(p_reviews)>1000 then
    raise exception 'Add between 1 and 1,000 reviews.';
  end if;
  foreach item in array p_reviews loop
    if item is null or length(btrim(item))<5 or length(item)>3000 then
      raise exception 'Every review must contain 5–3,000 characters. Nothing was imported.';
    end if;
    normalized := lower(btrim(regexp_replace(normalize(item,NFKC),'[[:space:]]+',' ','g')));
    insert into public.rd_mb_reviews(business_id, body, fingerprint)
    values(bid,btrim(item),public.rd_mb_hash(normalized))
    on conflict(business_id,fingerprint) do nothing;
    get diagnostics changed = row_count;
    inserted := inserted + changed;
  end loop;
  return jsonb_build_object('added',inserted,'duplicates',cardinality(p_reviews)-inserted);
end;
$$;

create or replace function public.rd_mb_add_review(p_review text) returns jsonb
language plpgsql security definer set search_path='' as $$
declare bid uuid; clean text; normalized text; rid bigint;
begin
  bid := public.rd_mb_assert_admin();
  clean := btrim(coalesce(p_review,''));
  if length(clean)<5 or length(clean)>3000 then raise exception 'Review must contain 5–3,000 characters.'; end if;
  normalized := lower(btrim(regexp_replace(normalize(clean,NFKC),'[[:space:]]+',' ','g')));
  insert into public.rd_mb_reviews(business_id,body,fingerprint)
  values(bid,clean,public.rd_mb_hash(normalized))
  on conflict(business_id,fingerprint) do nothing
  returning id into rid;
  if rid is null then return jsonb_build_object('added',0,'duplicates',1); end if;
  return jsonb_build_object('added',1,'duplicates',0);
end;
$$;

create or replace function public.rd_mb_public_business(p_slug text) returns jsonb
language sql security definer set search_path='' as $$
  select case when b.id is null then null else
    jsonb_build_object('name',b.name,'slug',b.slug,'url',b.google_review_url)
  end
  from public.rd_mb_businesses b
  where b.slug=public.rd_mb_normalize_slug(p_slug);
$$;

create or replace function public.rd_mb_claim(p_slug text, p_previous text default null) returns jsonb
language plpgsql security definer set search_path='' as $$
declare bid uuid; destination text; chosen public.rd_mb_reviews%rowtype; previous_id bigint; secret text; deadline timestamptz;
begin
  select id,google_review_url into bid,destination from public.rd_mb_businesses where slug=public.rd_mb_normalize_slug(p_slug);
  if bid is null then raise exception 'Business not found.'; end if;
  if destination='' then raise exception 'This business has not configured its Google review link yet.'; end if;
  if p_previous is not null and length(p_previous)>128 then raise exception 'Invalid reservation.'; end if;

  if p_previous is not null then
    select id into previous_id from public.rd_mb_reviews where business_id=bid and lease_hash=public.rd_mb_hash(p_previous);
    update public.rd_mb_reviews set lease_hash=null,expires_at=null
    where business_id=bid and lease_hash=public.rd_mb_hash(p_previous) and used_at is null;
  end if;

  select * into chosen from public.rd_mb_reviews
  where business_id=bid
    and used_at is null
    and (expires_at is null or expires_at<=clock_timestamp())
    and (previous_id is null or id<>previous_id)
    and length(btrim(body)) >= 5
  order by id for update skip locked
  limit 1;
  if not found then return jsonb_build_object('review',null,'business',jsonb_build_object('name',(select name from public.rd_mb_businesses where id=bid),'slug',(select slug from public.rd_mb_businesses where id=bid),'url',destination)); end if;

  secret := gen_random_uuid()::text||gen_random_uuid()::text;
  deadline := clock_timestamp()+interval '120 seconds';
  update public.rd_mb_reviews set lease_hash=public.rd_mb_hash(secret),expires_at=deadline where id=chosen.id;

  return jsonb_build_object(
    'review',jsonb_build_object('text',chosen.body,'lease',secret,'expires',extract(epoch from deadline)*1000),
    'business',jsonb_build_object('name',(select name from public.rd_mb_businesses where id=bid),'slug',(select slug from public.rd_mb_businesses where id=bid),'url',destination)
  );
end;
$$;

create or replace function public.rd_mb_renew(p_slug text,p_token text) returns jsonb
language plpgsql security definer set search_path='' as $$
declare bid uuid; deadline timestamptz:=clock_timestamp()+interval '120 seconds';
begin
  select id into bid from public.rd_mb_businesses where slug=public.rd_mb_normalize_slug(p_slug);
  if bid is null then raise exception 'Business not found.'; end if;
  if p_token is null or length(p_token)>128 then raise exception 'Invalid reservation.'; end if;
  update public.rd_mb_reviews set expires_at=deadline
  where business_id=bid and lease_hash=public.rd_mb_hash(p_token) and used_at is null and expires_at>clock_timestamp();
  if not found then raise exception 'Draft expired. Choose Next review.'; end if;
  return jsonb_build_object('expires',extract(epoch from deadline)*1000);
end;
$$;

create or replace function public.rd_mb_use(p_slug text,p_token text) returns jsonb
language plpgsql security definer set search_path='' as $$
declare bid uuid; destination text; chosen public.rd_mb_reviews%rowtype;
begin
  select id,google_review_url into bid,destination from public.rd_mb_businesses where slug=public.rd_mb_normalize_slug(p_slug);
  if bid is null then raise exception 'Business not found.'; end if;
  if destination='' then raise exception 'Google review link is not configured.'; end if;
  if p_token is null or length(p_token)>128 then raise exception 'Invalid reservation.'; end if;
  select * into chosen from public.rd_mb_reviews where business_id=bid and lease_hash=public.rd_mb_hash(p_token) for update;
  if not found then raise exception 'Draft expired. Choose Next review.'; end if;
  if chosen.expires_at<=clock_timestamp() then raise exception 'Draft expired. Choose Next review.'; end if;
  -- Mark the selected review as used. Keep its body, but exclude it from
  -- all future customer claims.
  update public.rd_mb_reviews
    set used_at=coalesce(used_at,clock_timestamp()), expires_at=null, lease_hash=null
    where id=chosen.id;
  return jsonb_build_object('ok',true,'url',destination);
end;
$$;

create or replace function public.rd_mb_protect_used() returns trigger
language plpgsql set search_path='' as $$
begin
  if old.used_at is not null then raise exception 'Used reviews cannot be restored, changed or deleted.'; end if;
  if tg_op='DELETE' then return old; end if;
  return new;
end;
$$;

drop trigger if exists rd_mb_used_guard on public.rd_mb_reviews;
create trigger rd_mb_used_guard before update or delete on public.rd_mb_reviews
for each row execute function public.rd_mb_protect_used();

revoke all on function public.rd_mb_hash(text),public.rd_mb_normalize_slug(text),public.rd_mb_assert_auth(),public.rd_mb_business_for_user(),public.rd_mb_assert_admin(),public.rd_mb_validate_google_url(text),public.rd_mb_protect_used() from public,anon,authenticated;
revoke all on function public.rd_mb_register_business(text,text,text),public.rd_mb_my_business(),public.rd_mb_admin_settings(text,text),public.rd_mb_import_reviews(text[]),public.rd_mb_add_review(text) from public,anon,authenticated;
revoke all on function public.rd_mb_public_business(text),public.rd_mb_claim(text,text),public.rd_mb_renew(text,text),public.rd_mb_use(text,text) from public,anon,authenticated;

grant execute on function public.rd_mb_register_business(text,text,text),public.rd_mb_my_business(),public.rd_mb_admin_settings(text,text),public.rd_mb_import_reviews(text[]),public.rd_mb_add_review(text) to authenticated;
grant execute on function public.rd_mb_public_business(text),public.rd_mb_claim(text,text),public.rd_mb_renew(text,text),public.rd_mb_use(text,text) to anon,authenticated;

commit;

-- Force PostgREST to refresh its RPC/function schema cache immediately.
notify pgrst, 'reload schema';
