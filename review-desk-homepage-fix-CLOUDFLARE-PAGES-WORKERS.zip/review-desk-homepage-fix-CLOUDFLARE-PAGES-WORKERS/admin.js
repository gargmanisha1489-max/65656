const $=id=>document.getElementById(id);
let qrUrl='',business=null;
const say=text=>{$('message').textContent=text||''};
function setTheme(mode){document.documentElement.dataset.theme=mode;$('theme').textContent=mode==='light'?'☾ Dark':'☀ Light';localStorage.setItem('review-admin-theme',mode)}
setTheme(localStorage.getItem('review-admin-theme')||'light');
$('theme').onclick=()=>setTheme(document.documentElement.dataset.theme==='dark'?'light':'dark');
function form(id,fn){$(id).onsubmit=async e=>{e.preventDefault();const b=e.submitter;if(b)b.disabled=true;try{await fn()}catch(err){say(err.message||'Something went wrong.')}finally{if(b)b.disabled=false}}}
function switchTab(tab){document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x.dataset.tab===tab));$('loginBox').hidden=tab!=='login';$('signupBox').hidden=tab!=='signup';}
function slugify(value){return value.toLowerCase().trim().normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').slice(0,60);}
document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>switchTab(b.dataset.tab));
if(new URLSearchParams(location.search).get('register')==='1')switchTab('signup');
$('businessName').addEventListener('input',()=>{if(!$('businessSlug').dataset.edited)$('businessSlug').value=slugify($('businessName').value)});
$('businessSlug').dataset.edited='';
$('businessSlug').addEventListener('input',()=>{$('businessSlug').dataset.edited='1';$('businessSlug').value=slugify($('businessSlug').value)});
function publicUrl(){
  return new URL('/'+encodeURIComponent(business.slug),location.origin).href;
}
function qrProxyUrl(){
  return '/qr-proxy?size=700&margin=2&text='+encodeURIComponent(publicUrl());
}
function renderQr(){
  qrUrl=qrProxyUrl();
  $('qrPreview').innerHTML='';
  const img=document.createElement('img');
  img.alt='QR code for '+business.name;
  img.loading='eager';
  img.src=qrUrl;
  img.onerror=()=>{
    // Keep the QR usable even when the site is being previewed outside Netlify.
    qrUrl='https://quickchart.io/qr?size=700&margin=2&text='+encodeURIComponent(publicUrl());
    img.src=qrUrl;
  };
  $('qrPreview').append(img);
}
function renderDashboard(data){
  business=data.business; if(!business)return showSetup();
  $('setupBox').hidden=true;$('authArea').hidden=true;$('dashboard').hidden=false;$('logout').hidden=false;
  $('dashName').textContent=business.name;$('dashUrl').textContent=publicUrl();$('publicUrl').value=publicUrl();$('settingsName').value=business.name;$('settingsUrl').value=business.url||'';
  for(const key of ['total','available','reserved','used'])$(key).textContent=data.stats?.[key]??0;
  renderQr();
}
function showSetup(){ $('dashboard').hidden=true;$('authArea').hidden=true;$('setupBox').hidden=false;$('logout').hidden=false; }
async function load(){
  try{
    ReviewDB.config();
    if(!ReviewDB.hasSession()){
      $('authArea').hidden=false;$('dashboard').hidden=true;$('setupBox').hidden=true;$('logout').hidden=true;
      switchTab('login');
      return;
    }
    const data=await ReviewDB.rpc('rd_mb_my_business',{},true);
    if(data.business) renderDashboard(data);
    else showSetup();
  }catch(e){
    if(ReviewDB.hasSession()){
      showSetup();
      say((e.message||'Could not load your business profile.')+' You are signed in; complete or retry the business setup.');
    }else{
      ReviewDB.reset();
      $('authArea').hidden=false;$('dashboard').hidden=true;$('setupBox').hidden=true;$('logout').hidden=true;
      switchTab('login');
      say(e.message||'Please sign in.');
    }
  }
}
form('loginForm',async()=>{await ReviewDB.login($('email').value.trim(),$('password').value);$('password').value='';say('Signed in.');await load()});
form('signupForm',async()=>{const d=await ReviewDB.signup($('signupEmail').value.trim(),$('signupPassword').value);if(d.access_token){say('Account created. Complete your business profile below.');await load()}else{say('Account created. Confirm your email if Supabase requires confirmation, then sign in here.');switchTab('login')}});
form('businessForm',async()=>{
  if(!ReviewDB.hasSession()) throw new Error('Please sign in first.');
  const name=$('businessName').value.trim();
  const slug=slugify($('businessSlug').value);
  const reviewUrl=$('businessUrl').value.trim();
  if(name.length<2||name.length>100) throw new Error('Business name must be 2–100 characters.');
  if(slug.length<3||slug.length>60) throw new Error('Business URL slug must be 3–60 characters.');
  if(reviewUrl && !/^https:\/\/(g\.page|maps\.app\.goo\.gl|goo\.gl|([a-zA-Z0-9-]+\.)*google\.com)(\/[^\s]*)?$/.test(reviewUrl)) throw new Error('Enter a valid HTTPS Google review link.');
  const userId=ReviewDB.session()?.user?.id;
  if(!userId) throw new Error('Your signed-in user session could not be read. Please sign in again.');
  // Use the database registration RPC so slug validation, reserved slugs,
  // ownership and the business record are handled in one place.
  const d=await ReviewDB.rpc('rd_mb_register_business',{
    p_name:name,
    p_slug:slug,
    p_url:reviewUrl
  },true);
  if(!d?.business) throw new Error('Business was created, but its profile could not be loaded.');
  business=d.business;
  say('Business created. Your public page is ready.');
  renderDashboard(d);
});
form('singleForm',async()=>{const d=await ReviewDB.rpc('rd_mb_add_review',{p_review:$('singleReview').value},true);$('singleReview').value='';await load();say(d.added? 'Review added.':'This review already exists, so it was skipped.')});
form('importForm',async()=>{const reviews=$('bulk').value.split(/\r?\n\s*---\s*\r?\n/).map(x=>x.trim()).filter(Boolean);const d=await ReviewDB.rpc('rd_mb_import_reviews',{p_reviews:reviews},true);$('bulk').value='';$('file').value='';await load();say(`${d.added} reviews added. ${d.duplicates} duplicates skipped.`)});
form('settingsForm',async()=>{const d=await ReviewDB.rpc('rd_mb_admin_settings',{p_name:$('settingsName').value,p_url:$('settingsUrl').value},true);renderDashboard(d);say('Business settings saved.')});
$('file').onchange=async()=>{try{const file=$('file').files[0];if(!file)return;if(file.size>1000000)throw new Error('Maximum file size is 1 MB.');$('bulk').value=await file.text()}catch(e){say(e.message)}};
$('copyUrl').onclick=async()=>{try{await navigator.clipboard.writeText(publicUrl());say('Public business URL copied.')}catch{say('Copy blocked. Select and copy the URL manually.')}};
$('openPublic').onclick=()=>{window.location.assign(publicUrl())};
$('downloadQr').onclick=async()=>{
  const button=$('downloadQr');if(!business)return;
  button.disabled=true;
  try{
    const url='https://quickchart.io/qr?format=png&size=900&margin=3&text='+encodeURIComponent(publicUrl());
    const response=await fetch(url,{mode:'cors',cache:'no-store'});
    if(!response.ok)throw new Error('QR image service did not respond.');
    const blob=await response.blob();if(!blob.type.includes('image'))throw new Error('QR image was not returned.');
    const blobUrl=URL.createObjectURL(blob);const a=document.createElement('a');
    a.href=blobUrl;a.download=(business.slug||'business')+'-review-qr.png';a.style.display='none';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(blobUrl),3000);say('QR code downloaded.');
  }catch(e){
    const url='https://quickchart.io/qr?format=png&size=900&margin=3&text='+encodeURIComponent(publicUrl());
    const a=document.createElement('a');a.href=url;a.target='_blank';a.rel='noopener';a.click();say('Your QR code opened in a new tab. Use the image menu or right-click to save it.');
  }finally{button.disabled=false}
};
$('logout').onclick=async()=>{try{await ReviewDB.logout()}catch{}business=null;$('dashboard').hidden=true;$('setupBox').hidden=true;$('authArea').hidden=false;$('logout').hidden=true;switchTab('login');say('Signed out.')};
(async()=>{try{ReviewDB.config()}catch(e){say(e.message);return}await load()})();
