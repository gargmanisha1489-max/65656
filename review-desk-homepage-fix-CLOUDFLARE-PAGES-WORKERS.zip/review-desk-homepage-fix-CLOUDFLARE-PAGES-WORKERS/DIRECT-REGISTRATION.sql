-- Registration fallback/repair
-- This removes the dependency on PostgREST discovering rd_mb_register_business().
-- Run this once in the SAME Supabase project used by config.js.

begin;

-- Allow an authenticated owner to create only a business belonging to themselves.
drop policy if exists rd_mb_business_insert_owner on public.rd_mb_businesses;
create policy rd_mb_business_insert_owner
on public.rd_mb_businesses
for insert
to authenticated
with check (owner_user_id = auth.uid());

-- DB-level validation so direct REST inserts cannot bypass the app validation.
alter table public.rd_mb_businesses
  drop constraint if exists rd_mb_businesses_slug_format;
alter table public.rd_mb_businesses
  add constraint rd_mb_businesses_slug_format
  check (slug ~ '^[a-z0-9]+(?:-[a-z0-9]+)*$' and length(slug) between 3 and 60);

alter table public.rd_mb_businesses
  drop constraint if exists rd_mb_businesses_reserved_slug;
alter table public.rd_mb_businesses
  add constraint rd_mb_businesses_reserved_slug
  check (slug not in ('admin','api','login','signup','dashboard','review','reviews','index','favicon','robots','sitemap'));

alter table public.rd_mb_businesses
  drop constraint if exists rd_mb_businesses_google_url;
alter table public.rd_mb_businesses
  add constraint rd_mb_businesses_google_url
  check (
    google_review_url = '' or
    google_review_url ~ '^https://(g[.]page|maps[.]app[.]goo[.]gl|goo[.]gl|([a-zA-Z0-9-]+[.])*google[.]com)(/[^[:space:]]*)?$'
  );

-- Create the matching admin row automatically whenever a business is created.
create or replace function public.rd_mb_auto_admin()
returns trigger
language plpgsql
security definer
set search_path=''
as $$
begin
  insert into public.rd_mb_admins(business_id, user_id)
  values (new.id, new.owner_user_id)
  on conflict (user_id) do nothing;
  return new;
end;
$$;

drop trigger if exists rd_mb_business_auto_admin on public.rd_mb_businesses;
create trigger rd_mb_business_auto_admin
after insert on public.rd_mb_businesses
for each row execute function public.rd_mb_auto_admin();

revoke all on function public.rd_mb_auto_admin() from public, anon, authenticated;

commit;

notify pgrst, 'reload schema';
