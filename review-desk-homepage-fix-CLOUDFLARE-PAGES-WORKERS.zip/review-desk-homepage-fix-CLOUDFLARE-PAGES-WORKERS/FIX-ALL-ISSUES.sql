-- FIX FOR: Could not find function public.rd_mb_register_business(p_name, p_slug, p_url) in schema cache
-- Run this AFTER setup-multibusiness.sql if your project was created from an older ZIP.

begin;

drop function if exists public.rd_mb_register_business(text,text);
drop function if exists public.rd_mb_register_business(text,text,text);

create or replace function public.rd_mb_register_business(p_name text, p_slug text, p_url text) returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare
  bid uuid;
  clean_slug text;
  clean_name text;
  clean_url text;
begin
  perform public.rd_mb_assert_auth();

  if exists (select 1 from public.rd_mb_admins where user_id = auth.uid()) then
    select business_id into bid
    from public.rd_mb_admins
    where user_id = auth.uid()
    limit 1;
    return public.rd_mb_my_business();
  end if;

  clean_name := btrim(coalesce(p_name,''));
  clean_slug := public.rd_mb_normalize_slug(p_slug);
  clean_url := btrim(coalesce(p_url,''));

  if length(clean_name) < 2 or length(clean_name) > 100 then
    raise exception 'Business name must be 2–100 characters.';
  end if;

  if length(clean_slug) < 3 or length(clean_slug) > 60
     or clean_slug !~ '^[a-z0-9]+(?:-[a-z0-9]+)*$' then
    raise exception 'Business URL must contain 3–60 lowercase letters, numbers, and hyphens.';
  end if;

  if clean_slug in ('admin','api','login','signup','dashboard','review','reviews','index','favicon','robots','sitemap') then
    raise exception 'That business URL is reserved. Choose another one.';
  end if;

  if clean_url <> '' and not public.rd_mb_validate_google_url(clean_url) then
    raise exception 'Enter a valid HTTPS Google review link.';
  end if;

  if exists (select 1 from public.rd_mb_businesses where slug = clean_slug) then
    raise exception 'That business URL is already taken. Choose another one.' using errcode='23505';
  end if;

  insert into public.rd_mb_businesses(owner_user_id, name, slug, google_review_url)
  values(auth.uid(), clean_name, clean_slug, clean_url)
  returning id into bid;

  insert into public.rd_mb_admins(business_id, user_id)
  values(bid, auth.uid());

  return jsonb_build_object(
    'business', jsonb_build_object(
      'id', bid,
      'name', clean_name,
      'slug', clean_slug,
      'url', clean_url
    )
  );
end;
$$;

revoke all on function public.rd_mb_register_business(text,text,text) from public, anon, authenticated;
grant execute on function public.rd_mb_register_business(text,text,text) to authenticated;

commit;

notify pgrst, 'reload schema';
-- FIX: duplicate key value violates unique constraint "rd_mb_admins_pkey"
-- Cause: an older/direct-registration trigger can create the admin row
-- automatically, while the registration RPC also creates it.
-- This makes registration safe even when that trigger exists.

begin;

-- Make the registration function idempotent with respect to the admin row.
create or replace function public.rd_mb_register_business(p_name text, p_slug text, p_url text) returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare
  bid uuid;
  clean_slug text;
  clean_name text;
  clean_url text;
begin
  perform public.rd_mb_assert_auth();

  if exists (select 1 from public.rd_mb_admins where user_id = auth.uid()) then
    select business_id into bid
    from public.rd_mb_admins
    where user_id = auth.uid()
    limit 1;
    return public.rd_mb_my_business();
  end if;

  clean_name := btrim(coalesce(p_name,''));
  clean_slug := public.rd_mb_normalize_slug(p_slug);
  clean_url := btrim(coalesce(p_url,''));

  if length(clean_name) < 2 or length(clean_name) > 100 then
    raise exception 'Business name must be 2–100 characters.';
  end if;

  if length(clean_slug) < 3 or length(clean_slug) > 60
     or clean_slug !~ '^[a-z0-9]+(?:-[a-z0-9]+)*$' then
    raise exception 'Business URL must contain 3–60 lowercase letters, numbers, and hyphens.';
  end if;

  if clean_slug in ('admin','api','login','signup','dashboard','review','reviews','index','favicon','robots','sitemap') then
    raise exception 'That business URL is reserved. Choose another one.';
  end if;

  if clean_url <> '' and not public.rd_mb_validate_google_url(clean_url) then
    raise exception 'Enter a valid HTTPS Google review link.';
  end if;

  if exists (select 1 from public.rd_mb_businesses where slug = clean_slug) then
    raise exception 'That business URL is already taken. Choose another one.' using errcode='23505';
  end if;

  insert into public.rd_mb_businesses(owner_user_id, name, slug, google_review_url)
  values(auth.uid(), clean_name, clean_slug, clean_url)
  returning id into bid;

  -- Safe if rd_mb_auto_admin trigger is also installed.
  insert into public.rd_mb_admins(business_id, user_id)
  values(bid, auth.uid())
  on conflict (business_id, user_id) do nothing;

  return jsonb_build_object(
    'business', jsonb_build_object(
      'id', bid,
      'name', clean_name,
      'slug', clean_slug,
      'url', clean_url
    )
  );
end;
$$;

revoke all on function public.rd_mb_register_business(text,text,text) from public, anon, authenticated;
grant execute on function public.rd_mb_register_business(text,text,text) to authenticated;

commit;
notify pgrst, 'reload schema';
