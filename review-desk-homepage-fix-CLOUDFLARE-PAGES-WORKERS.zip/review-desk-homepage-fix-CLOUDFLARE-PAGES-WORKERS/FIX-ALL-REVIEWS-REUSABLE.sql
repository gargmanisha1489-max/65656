-- REVIEW DESK: SHOW ALL REMAINING UNUSED REVIEWS
-- Run this AFTER setup-multibusiness.sql on the existing Supabase project.
-- USED reviews remain excluded. Every review with used_at IS NULL remains
-- available to customers until that review is actually used.

begin;

create or replace function public.rd_mb_claim(p_slug text, p_previous text default null)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare
  bid uuid;
  destination text;
  chosen public.rd_mb_reviews%rowtype;
  previous_id bigint;
  secret text;
  deadline timestamptz;
begin
  select id, google_review_url
    into bid, destination
  from public.rd_mb_businesses
  where slug=public.rd_mb_normalize_slug(p_slug);

  if bid is null then raise exception 'Business not found.'; end if;
  if destination='' then raise exception 'This business has not configured its Google review link yet.'; end if;
  if p_previous is not null and length(p_previous)>128 then raise exception 'Invalid reservation.'; end if;

  if p_previous is not null then
    select id into previous_id
    from public.rd_mb_reviews
    where business_id=bid and lease_hash=public.rd_mb_hash(p_previous);

    update public.rd_mb_reviews
      set lease_hash=null, expires_at=null
    where business_id=bid
      and lease_hash=public.rd_mb_hash(p_previous)
      and used_at is null;
  end if;

  select * into chosen
  from public.rd_mb_reviews
  where business_id=bid
    and used_at is null
    and (expires_at is null or expires_at<=clock_timestamp())
    and (previous_id is null or id<>previous_id)
    and length(btrim(body)) >= 5
  order by id
  limit 1
  for update skip locked;

  if not found then
    return jsonb_build_object(
      'review',null,
      'business',jsonb_build_object(
        'name',(select name from public.rd_mb_businesses where id=bid),
        'slug',(select slug from public.rd_mb_businesses where id=bid),
        'url',destination
      )
    );
  end if;

  secret := gen_random_uuid()::text||gen_random_uuid()::text;
  deadline := clock_timestamp()+interval '120 seconds';

  update public.rd_mb_reviews
    set lease_hash=public.rd_mb_hash(secret), expires_at=deadline
  where id=chosen.id;

  return jsonb_build_object(
    'review',jsonb_build_object(
      'text',chosen.body,
      'lease',secret,
      'expires',extract(epoch from deadline)*1000
    ),
    'business',jsonb_build_object(
      'name',(select name from public.rd_mb_businesses where id=bid),
      'slug',(select slug from public.rd_mb_businesses where id=bid),
      'url',destination
    )
  );
end;
$$;

create or replace function public.rd_mb_use(p_slug text,p_token text)
returns jsonb
language plpgsql
security definer
set search_path=''
as $$
declare
  bid uuid;
  destination text;
  chosen public.rd_mb_reviews%rowtype;
begin
  select id,google_review_url
    into bid,destination
  from public.rd_mb_businesses
  where slug=public.rd_mb_normalize_slug(p_slug);

  if bid is null then raise exception 'Business not found.'; end if;
  if destination='' then raise exception 'Google review link is not configured.'; end if;
  if p_token is null or length(p_token)>128 then raise exception 'Invalid reservation.'; end if;

  select * into chosen
  from public.rd_mb_reviews
  where business_id=bid
    and lease_hash=public.rd_mb_hash(p_token)
  for update;

  if not found then raise exception 'Draft expired. Choose Next review.'; end if;
  if chosen.expires_at<=clock_timestamp() then raise exception 'Draft expired. Choose Next review.'; end if;

  -- Mark this review as USED. Keep its body for audit/history, but
  -- rd_mb_claim will permanently exclude it from future customers.
  update public.rd_mb_reviews
    set used_at=coalesce(used_at, clock_timestamp()), expires_at=null, lease_hash=null
  where id=chosen.id;

  return jsonb_build_object('ok',true,'url',destination);
end;
$$;

grant execute on function public.rd_mb_claim(text,text) to anon,authenticated;
grant execute on function public.rd_mb_use(text,text) to anon,authenticated;

notify pgrst, 'reload schema';

commit;
